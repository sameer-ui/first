export interface LoginModel {
    $id: string
    UserDetails: UserDetails
    CurrentYears: CurrentYear[]
    InstituteDetails: InstituteDetail[]
  }
  
  export interface UserDetails {
    $id: string
    UserName: string
    UserPassword: string
    InstituteIds: string
    UserId: number
  }
  
  export interface CurrentYear {
    $id: string
    YearID: number
    DisplayYear: string
    YearType: string
    InstituteID:number
  }
  
  export interface InstituteDetail {
    $id: string
    InstituteName: string
    instituteAddress: string
    Institutelogo: any
    InstituteId:number;
    Description:string
  }