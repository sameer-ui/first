export class ResponseModel
{
   
    public ResponseStatus:string;    //  Success, Error, Warning
    public ResponseMessage:string;
    public ResponseBody:any;

    public ResponseCode :number;
    public ErrorMessage:string;
    public WarningMessage:string;
    public SuccessMessage:string;

  
}