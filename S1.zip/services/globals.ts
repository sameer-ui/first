import { Injectable } from '@angular/core';
import {LoginModel} from './general';

import {LocalStorageService, SessionStorageService} from 'ngx-webstorage';
@Injectable()
export class Globals {

  role: string = 'test';
  isLogin:boolean=false;
  InstituteName:string;
  UserId:number;
  InstituteId:number=0;
  YearId:number;
  loginModel:LoginModel;
  UserName: string;
  InstituteLogo: any;
  AccountYearId: number;
  WorkingDate:any;
 // WorkingDatePass:any;
  AccountYear:string;
  

  reportUrl=
            "http://sudhakar/testReport/";//--Local Sudhakar PC
            //"http://testerp.biyanitechnologies.com/reports/";
            //"http://103.232.25.67:100/reports/";
           // "http://ssvss.biyanitechnologies.com/Reportss/";


  ngOnInit()
  {

  }
  getFormattedDate(strDate)
  {
 //------------------
 var dateString = strDate;    
 var dateParts = dateString. split("/");      
 var dateObject = new Date(+dateParts[2], dateParts[1]-1, +dateParts[0]+1);  
 //var dateObject = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0]);     
 return dateObject;
 //------------------
  }
  
 
  getDateString(strDate)
  {
 //------------------
 var objDate = new Date(strDate);    
 var d = objDate.getDate();
 var m = objDate.getMonth()+1;
 var y = objDate.getFullYear(); 
 var cDate =m+'-'+d+'-'+y;       
 return cDate;
 //------------------
  }
  constructor(private localSt:LocalStorageService)
  {
     //localSt.clear();
     var res= localSt.retrieve("loginData");
     if(res===undefined)
     {
      // alert("undefined");
     }
     else
     {
       // alert("In Glod=gal:-"+JSON.stringify( this.localSt.retrieve("loginData")));
      try{
       this.loginModel=res;
       this.UserId=this.loginModel.UserDetails.UserId;
       this.UserName=this.loginModel.UserDetails.UserName;
       this.isLogin=true;
       try {
            this.InstituteId= localSt.retrieve("InstituteId");
            this.AccountYearId= localSt.retrieve("AccountYearId");
            this.InstituteName= localSt.retrieve("InstituteName");
            this.AccountYear= localSt.retrieve("AccountYear");
          

       } catch (error)
       {
       
     
       }
       try 
       {
    
         var today = new Date( localSt.retrieve("WorkingDate"));
         var dd = String(today.getDate()).padStart(2, '0');
         var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
         var yyyy = today.getFullYear();
         var tdate = mm + '/' + dd + '/' + yyyy;
     
         this.WorkingDate=tdate;
       } catch (error) {
         
       }


      /*  var today = new Date();
       var dd = String(today.getDate()).padStart(2, '0');
       var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
       var yyyy = today.getFullYear();
       
       var tdate = mm + '/' + dd + '/' + yyyy;
      // alert(tdate);          
       this.WorkingDate=tdate;
       localSt.store("WorkingDate",this.WorkingDate); */
      }catch(error)
      {
      }

     }
  }
  
}