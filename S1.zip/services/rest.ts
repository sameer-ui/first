import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject, asapScheduler, pipe, of, from, interval, merge, fromEvent } from 'rxjs';
import { map, filter, scan } from 'rxjs/operators';
/*
  Generated class for the RestProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/


let api=  
        //"http://DESKTOP-11K8SP8/SSVSSWebAPI/WebAPI/";  // Local Anilsir PC
        //"http://localhost/SSVSSWebAPI/api/";//--Local Sameer PC  
        //"http://desktop-hk3hh68/SSVSSWebAPI/api/";//--Local Sameer PC            
        //"http://DESKTOP-HK3HH68/SSVSSWebAPI/api/";//--Local Sameer PC
        "http://desktop-bds3ppk/ERP/api/";   //--Local Dilip PC
       //"http://ssvss.biyanitechnologies.com/WebAPI/api/";//--Live ssvss


let ioApi=
          //"http://DESKTOP-11K8SP8/SSVSSWebAPI/WebAPI/";  // Local Anilsir PC
          //"http://localhost/SSVSSWebAPI/api/"; //--Local Sameer PC 
          //"http://desktop-hk3hh68/SSVSSWebAPI/api/";//--Local Sameer PC    
          //"http://DESKTOP-HK3HH68/SSVSSWebAPI/api/"; //--Local Sameer PC          
          "http://desktop-bds3ppk/ERP/api/";       //Local Dilip PC 
          //"http://ssvss.biyanitechnologies.com/WebAPI/api/"; 


@Injectable()
export class RestProvider
 {
   url:string;
  constructor(public http: HttpClient)
  {
    console.log('Hello RestProvider Provider');
    this.url=ioApi;
  }

  postData(credentials, type) {
    return new Promise((resolve, reject) => {
      let lHeaders = new HttpHeaders();
       lHeaders.set('Content-Type','application/json');
     //  lHeaders.set('Access-Control-Allow-Origin','*');
       lHeaders.set('Access-Control-Allow-Methods','POST, PUT, DELETE');
       lHeaders.set('Access-Control-Allow-Headers','Cache-Control, Pragma, Origin, Authorization, Content-Type, X-Requested-With');
     // alert(api + type);
      this.http.post(api + type, credentials, {headers: lHeaders})
        .subscribe(res => {
          resolve(res);
        }, (err) => {
          alert("Errorr:-   "+JSON.stringify(err));
          reject(err);
        });
    });

  }


  postDataApi(credentials,type) {
    
    return new Promise((resolve, reject) => {
      let lHeaders = new HttpHeaders();
       lHeaders.set('Content-Type','application/json');
       lHeaders.set('Access-Control-Allow-Origin','*');
       lHeaders.set('Access-Control-Allow-Methods','POST, PUT, DELETE');
      // lHeaders.set('Access-Control-Allow-Headers','Cache-Control, Pragma, Origin, Authorization, Content-Type, X-Requested-With');
    
      // lHeaders.set('Access-Control-Allow-Headers', 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,Origin,Accept,Access-Control-Allow-Headers,Access-Control-Allow-Methods,Access-Control-Allow-Origin');
       // alert(api + type);
      this.http.post(ioApi+type , credentials, {headers: lHeaders})
        .subscribe(res => {
         // alert("On Response "+JSON.stringify(res));
          resolve(res);
        }, (err) => {
        
          alert("Error  ---"+JSON.stringify(err));
          reject(err);
        });
    });

  }



  getData(credentials,type)
  {
   var url = api+type+"?"+credentials;

   //alert(url); 
   return new Promise<any>((resolve,reject) => 
   {
      this.http.get<any>(url).
            subscribe((res) =>
                             {
                                 resolve(res);
                             },
                       (err) =>
                             {
                                 alert("Error occured, please try again "+JSON.stringify(err));
                                 reject(err);
                             }
                      );
    });
  }


  getDataForEdit(credentials,type)
  {
   var url = api+type+"/"+credentials;

 //  alert(url); 
   return new Promise<any>((resolve,reject) => 
   {
      this.http.get<any>(url).
            subscribe((res) =>
                             {
                                 resolve(res);
                             },
                       (err) =>
                             {
                                 alert("Error occured, please try again "+JSON.stringify(err));
                                 reject(err);
                             }
                      );
    });
  }

 
  // deletedata(credentials,type)
  // {
  //   var url = api+type+"/"+credentials;
  //  // alert(url);
  //   return this.http.delete(url);
  // }

  deleteDataUrl(credentials,type)
  {

    var url = api+type+"/"+credentials;
    return this.http.delete(url);
    var url = api+type+"/"+credentials;
   
   alert(url); 
   return new Promise<any>((resolve,reject) => 
   {
     
      this.http.delete<any>(url).
            subscribe((res) =>
                             {
                                 resolve(res);
                             },
                       (err) =>
                             {
                                 alert("Error occured, please try again "+JSON.stringify(err));
                                 reject(err);
                             }
                      );
    });
  }

  getDataSpecial(credentials,type)
  {
    var url = api+type+"?"+credentials;
    //alert(url); 
   return new Promise((resolve,reject) => {
      this.http.get(url)  .subscribe(res => {
        resolve(res);
      }, (err) => {
        alert(err); 
        reject(err);
      });
    });
  }

  

  getHttpData(credentials,type):Observable<object>
  {
     var url = api+type+"?"+credentials;
     return  this.http.get(url);
  }



}
