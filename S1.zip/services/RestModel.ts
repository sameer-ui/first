import {Globals} from '../services/globals';
export class RestModel
{
    public  InstituteId:number;
    public  UserName:string;
    public  UserId:number;
    public  AcademicYearId:number;
    public  AccountYearID:number;
    public  WorkingDate:Date;
  
    public  objdata:any;
    
    constructor(global:Globals)
    {
        this.AcademicYearId=global.YearId;
        this.AccountYearID=global.AccountYearId;
        this.UserId=global.UserId;
        this.UserName=global.UserName;
        this.InstituteId=global.InstituteId;
        this.WorkingDate=global.WorkingDate;
    }
 

}