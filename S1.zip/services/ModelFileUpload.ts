export class ModelFileUpload
{
      public requestCode:string;
      public resultCode :string;
      public serverPath: string;
}