import { Component, OnInit,ViewChild } from '@angular/core';
import { Select2Data,Select2Option } from  '../../../../../node_modules/ng-select2-component';
import { FormGroup, FormControl,Validators  } from '@angular/forms';
import { Globals } from '../../../services/globals';
import {RestProvider} from  '../../../services/rest';
import { ActivatedRoute } from '@angular/router';
import {Router,NavigationExtras} from '@angular/router';
import { HttpClient ,HttpHeaders ,HttpRequest,HttpEventType,HttpSentEvent  } from '@angular/common/http';
import {ModelParent} from '../models/ModelGroup';
import {ModelNature} from '../models/Nature';
import {ModalDirective} from 'ngx-bootstrap/modal';
import {GroupListingModel} from './models/GroupListModel'
import{RestModel} from '../../../services/RestModel';
import {ResponseModel} from  '../../../services/ResponseModel';
import { from } from 'rxjs';

@Component({
  selector: 'app-groupmaster',
  templateUrl: './groupmaster.component.html',
  styleUrls: ['./groupmaster.component.scss']
})
export class GroupmasterComponent implements OnInit {

  @ViewChild('successModal') public successModal: ModalDirective;
   mode:number=0;
   restModel:RestModel;
   obj:GroupListingModel;
   getMode()
   {
     if(this.mode==0)
     {
       return "save";
     }
     else if(this.mode==1)
     {
       return "update";
     }
     else if(this.mode==2)
     {
       return "delete";
     }
     else
     {

     }
   }
    successAlert:boolean=false
    dangerAlert:boolean=false
    natureAlert:boolean=false
    AlertMessage:string;
    AlertNatureMessage:string;

   

  groupList:Select2Option[]=[];
  natureList:Select2Option[]=[];

  rest :RestProvider;
  global: Globals;
  nameList:ModelParent[];
  listNature:ModelNature[];
   
   route:Router;

  groupMasterForm=new FormGroup({
   
    GroupCode:new FormControl(''),
    GroupId:new FormControl(0),
    GroupName:new FormControl('',Validators.required),
    ParentGroupId:new FormControl(0), 
    GroupNameInMarathi:new FormControl(''),
    NatureId:new FormControl('',Validators.required),
    //NatureName:new FormControl('',Validators.required),
    EnteredBy:new FormControl(''),
    InstituteId:new FormControl(0),
    EnteredDate:new FormControl(''),
    ChangedBy:new FormControl(''),
    ChangedDate:new FormControl(''),
    DeleteStatus:new FormControl(0),
    Remark:new FormControl(''),
    ReportSequenceNo:new FormControl(''),
    DisplayGroupNameOnDayBook:new FormControl(0),

    

  });

  constructor(rest :RestProvider,globals: Globals, route :Router) { 

    this.restModel=new RestModel (globals);

    this.obj=new GroupListingModel();
    this.global=globals;
    this.rest=rest;
    this.route=route;
   // this.GroupId=0;
   
    //this.fillDropDown();
    this.setParentDropDown();
    this.setNatureDropDown();


   // this.groupMasterForm.controls.InstituteID.setValue(globals.InstituteId)

    try
    {
     
     const navigation = this.route.getCurrentNavigation();
     const state = navigation.extras.state as {
       data:any,
      
     };
     //let obj=new GroupListingModel(); 
    this.obj =state.data;
     this.initForEdit();

    // alert(JSON.stringify(obj));
    //  if(obj.GroupID>0)
    //  {
    //   alert("ok");
    //    this.groupMasterForm.controls.GroupId .setValue(obj.GroupID);
    //    this.groupMasterForm.controls['GroupName'].setValue(obj.GroupName);
    //    this.groupMasterForm.controls['ParentGroupId'].setValue(obj.ParentGroupName);
    //    this.groupMasterForm.controls['NatureId'].setValue(obj.NatureName);
    //    this.groupMasterForm.controls['ReportSequenceNo'].setValue(obj.PrintSequence);
       
    //  }
    } catch (error) {
      // alert("Catch Error");
    }


  }
 
 fillGroup()
 {
      for(let i=0;i<this.nameList.length;i++)
      {
         // alert(i+"-"+JSON.stringify(this.nameList[i]));
         let temp={"value":this.nameList[i].GroupId,"label":this.nameList[i].GroupName};    
         this.groupList.push(temp);
      } 
      
     // alert("fillgroup-"+JSON.stringify(this.groupList));
 }


fillNature() 
 {
      for(let i=0;i<this.listNature.length;i++)
      {
         // alert(i+"-"+JSON.stringify(this.listNature[i]));
         let temp={"value":this.listNature[i].NatureID,"label":this.listNature[i].NatureName};    
         this.natureList.push(temp);
      } 
      
     // alert("fillnature-"+JSON.stringify(this.natureList));
 }




setParentDropDown()
{
    
       this.rest.getData("InstituteId="+this.global.InstituteId,"FillDropDown/FillGroup")
     . then(
      (res)=>{   
            //alert("GRouplist "+   JSON.stringify(res));         

               this.nameList=res.ResponseBody;
              // alert("parentDropdown"+JSON.stringify( this.nameList));
               this.fillGroup();
                   
             }
         ).catch((err)=>{
             alert('Error Occure '+err);
         });
}
 


setNatureDropDown()
{
    
       this.rest.getData("InstituteId="+this.global.InstituteId,"FillDropDown/FillNature")
     . then(
      (res)=>{   
           // alert("Naturelist "+   JSON.stringify(res));         

               this.listNature=res.ResponseBody;
              // alert("natureDropdown"+JSON.stringify( this.listNature));
               this.fillNature();
                   
             }
         ).catch((err)=>{
             alert('Error Occure '+err);
         });
}



initForEdit()
  {
    //alert("Edit");
    if(this.obj.GroupID>0)
    {
       // alert("Edit 1");
       // this.rest.getData("GroupId="+this.obj.GroupID+"&instituteID="+this.global.InstituteId+"","AccountGroupMaster/GetGroup").then(
           // this.rest.getData("GroupId="+this.obj.GroupID+"&instituteID="+this.global.InstituteId,"AccountGroupMaster/GetGroup").then(
           // var str="GroupId="+this.obj.GroupID+"&instituteID="+this.global.InstituteId;
           // console.log (str);
            //this.rest.getData(str,"AccountGroupMaster/GetGroup").then(
              
              this.rest.getData("id="+this.obj.GroupID+"&InstituteId="+this.global.InstituteId,"AccountGroupMaster/GetGroup").then(  
            (res) => {
              //  console.log(res);
                    // alert("Edit Column");
                     //alert(JSON.stringify(res));
                let resModel:ResponseModel= JSON.parse( JSON.stringify( res)); 
                if( resModel.ResponseStatus==="Success")
                {

                
               this.groupMasterForm.controls.GroupId.setValue(this.obj.GroupID); 
               this.groupMasterForm.controls['GroupCode'].setValue(res.ResponseBody.GroupCode);
               this.groupMasterForm.controls['GroupName'].setValue(res.ResponseBody.GroupName);
               this.groupMasterForm.controls['GroupNameInMarathi'].setValue(res.ResponseBody.GroupNameInMarathi);
               this.groupMasterForm.controls['ParentGroupId'].setValue(res.ResponseBody.ParentGroupId);
               this.groupMasterForm.controls['NatureId'].setValue(res.ResponseBody.NatureId);  
               this.groupMasterForm.controls['ReportSequenceNo'].setValue(res.ResponseBody.ReportSequenceNo);
               
               this.groupMasterForm.controls['DisplayGroupNameOnDayBook'].setValue(res.ResponseBody.DisplayGroupNameOnDayBook); 
               this.groupMasterForm.controls['Remark'].setValue(res.ResponseBody.Remark); 
                }
                else  if( resModel.ResponseStatus==="Error")
                {
                    this.dangerAlert=true;
                   this.AlertMessage=resModel.ResponseMessage;
                }

              // this.groupMasterForm.controls['GroupCode'] .setValue(res[0].GroupCode);
              //  this.groupMasterForm.controls['GroupName'].setValue(res[0].GroupName);
              //  this.groupMasterForm.controls['GroupNameInMarathi'].setValue(res[0].GroupNameInMarathi);
              //  this.groupMasterForm.controls['ParentGroupId'].setValue(res[0].ParentGroupId);
              //  this.groupMasterForm.controls['NatureId'].setValue(res[0].NatureId);
              //  this.groupMasterForm.controls['ReportSequenceNo'].setValue(res[0].ReportSequenceNo);
              //  this.groupMasterForm.controls['Remark'].setValue(res[0].Remark);
             
              // this.groupcode=res[0].GroupID;
              // this.crdrapi=res[0].CreditDebit;
               
            }
             ).catch((err) => {
            //this.isProgress=false;
            alert('Error Occure ' + err);
            this.successModal.hide();
            
      
              });

    }
  }


  ngOnInit(): void {
  }

// fVal:string;
// showMe()
// {
//   this.fVal=JSON.stringify(this.groupMasterForm.value);
// }
 onSubmit()
  {
     //this.saveData();

    //  if(this.groupMasterForm.value.NatureId==0)
    // {
    //   alert("Select Nature");
    //   this.successModal.hide();
    // return;
     

    // }
  
     

    // this.groupMasterForm.value.InstituteId=this.global.InstituteId;
    // //alert(this.groupMasterForm.value);
    // this.rest.postDataApi(this.groupMasterForm.value,"AccountGroupMaster/AddGroup").then(
    //   (res)=>{
    //             //alert(JSON.stringify(res));
    //             //alert(res);
    //            // this.successModal.hide();
                
    //           //window.location.replace("#/account");
    //          // this.route.navigate(["./account"]);
    //           this.alert=true;
    //          }
    //      ).catch((err)=>{
    //          alert('Error Occure '+ err);
    //      });
  }
  closeAlert()
  {
     
     this.successAlert=false;
     this.groupMasterForm.reset();
  }
  closeDangerAlert()
  {
    this.dangerAlert=false;
    this.groupMasterForm.reset();
  }
  closeNatureAlert()
  {
    this.natureAlert=false;
  }

/* ModelBox Save Button */
  saveData()
  {
     //alert('ok');

    if(this.obj.GroupID===0 ||this.obj.GroupID===undefined )
    {
  
      // this.isProgress=true;      
        this.restModel.objdata=this.groupMasterForm.value;
        let intNatureID = this.restModel.objdata.NatureId;
        
        if(intNatureID ==0)
        {          
          this.successModal.hide();
          this.successAlert=false;
          this.natureAlert=true;
          
          this.AlertNatureMessage="Please Select Nature..!!";
          return; 
        }

        

        this.restModel.objdata.GroupId=0;
        this.restModel.objdata.DeleteStatus=0;
    this.groupMasterForm.value.InstituteId=this.global.InstituteId;
    //alert(this.branchMasterForm.value);
    //this.rest.postDataApi(this.groupMasterForm.value,"AccountGroupMaster/AddGroup").then(
      this.rest.postDataApi(this.restModel,"AccountGroupMaster/AddGroup").then(
      (res)=>{
             // alert("save");
             // alert(JSON.stringify(res));
             
            let resModel:ResponseModel= JSON.parse( JSON.stringify( res));
             //alert(resModel.ResponseMessage);
            if( resModel.ResponseStatus==="Success")
            {
              //alert("save--success");
             // alert(resModel.ResponseMessage); 
             this.successModal.hide();
             this.successAlert=true;
             this.dangerAlert=false;
             this.AlertMessage=resModel.ResponseMessage;
             this.groupMasterForm.reset();             
        
            }
            else  if( resModel.ResponseStatus==="Error")
            {
             this.dangerAlert=true;
             this.successAlert=false;
             this.AlertMessage=resModel.ResponseMessage;
            }
             
            
              
             }
         ).catch((err)=>{
             alert('Error Occure '+err);
         });
    }

    else if(this.obj.GroupID>0)
    {
    this.restModel.objdata=this.groupMasterForm.value;
    let intNatureID = this.restModel.objdata.NatureId;
    
    if(intNatureID==0 || intNatureID==null)
    {          
      this.successModal.hide();
      this.successAlert=false;
      this.dangerAlert=true;
      
      this.AlertMessage="Please Select Nature..!!";
      return; 
    }



    this.rest.postDataApi(this.restModel,"AccountGroupMaster/UpdateGroup").then(
      (res)=>{
             // alert(res);
           //  console.log(res);
            // alert(JSON.stringify(res));
            let resModel:ResponseModel= JSON.parse( JSON.stringify( res)); 
           // let resModel:ResponseModel=JSON.parse(res);

            if( resModel.ResponseStatus==="Success")
               {
               // alert("update--success");
                 //alert(resModel.ResponseMessage); 
                 this.successModal.hide();
                 this.successAlert=true;
                 this.dangerAlert=false;
                this.AlertMessage=resModel.ResponseMessage;
                this.groupMasterForm.reset();
               }
               else  if( resModel.ResponseStatus==="Error")
               {
                this.dangerAlert=true;
                this.successAlert=false;
                this.AlertMessage=resModel.ResponseMessage;
               }


              // this.successModal.hide();
              // this.successAlert=true;
              // this.groupMasterForm.reset();
              
             }
         ).catch((err)=>{
             alert('Error Occure '+err);
         });

  }


}
// checkBlurMethod()

// {
//  // alert("enter");
//   if(this.groupMasterForm.get('GroupCode').touched && this.groupMasterForm.get('GroupCode').valid)
//   {
//     //alert("Hello");
//   }
// }
}
