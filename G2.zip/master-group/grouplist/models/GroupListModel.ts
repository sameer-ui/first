export class GroupListingModel
 {
    
    GroupID: number;
    GroupName:string;
    ParentGroupName:string;   
    NatureName:string;
    PrintSequence:number;
}