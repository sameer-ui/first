export class ModelGroupName
{
    GroupId:number;
    GroupName:string;
}