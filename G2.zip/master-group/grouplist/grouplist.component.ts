import { Component, OnInit } from '@angular/core';
import {AfterViewInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { RestProvider } from '../../../../services/rest';
import { Globals } from '../../../../services/globals';
import {Router,NavigationExtras} from '@angular/router';
import {ModalDirective} from 'ngx-bootstrap/modal';
import {GroupListingModel} from './models/GroupListModel';
import { from } from 'rxjs';
import {ModelParent} from '../../models/ModelGroup';
import {ModelNature} from '../../models/Nature';
import {ModelGroupName} from './models/GroupNameDropdown';
import { Select2Data,Select2Option } from  '../../../../../../node_modules/ng-select2-component';
import { FormGroup, FormControl,Validators  } from '@angular/forms';
import {ResponseModel} from  '../../../../services/ResponseModel'


@Component({
  selector: 'app-grouplist',
  templateUrl: './grouplist.component.html',
  styleUrls: ['./grouplist.component.scss']
})
export class GrouplistComponent implements OnInit {
  @ViewChild('dangerModal', {static: false}) public dangerModal: ModalDirective;

  AlertMessage:string;
  dangerAlert:boolean=false
  successAlert:boolean=false

  groupListing:GroupListingModel[]=[];

  groupList:Select2Option[]=[];
  natureList:Select2Option[]=[];
  groupIdGroupNameList:Select2Option[]=[];

  nameList:ModelParent[];
  listNature:ModelNature[];
  listGroupName:ModelGroupName[];

  displayedColumns = ['GroupName','ParentGroupName','NatureName','PrintSequence','Edit','Delete'];
  //displayedColumns = ['GroupId','ParentGroupId','NatureId','ReportSequenceNo'];
  dataSource: MatTableDataSource<GroupListingModel>;
  route:Router;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  globals: Globals;
  restHtpp:RestProvider;
  

   groupForm=new FormGroup({
    GroupName:new FormControl(''),
    ParentGroupId:new FormControl(0),
    NatureId:new FormControl(0),  
    ReportSequenceNo:new FormControl(0)
  })

  constructor(globals: Globals, restHtpp:RestProvider,  route:Router) { 
    this.route=route;
   this.restHtpp=restHtpp;
   this.globals=globals;
   

   //this.globals.InstituteId=0;
   //this.globals.UserId=0;
   //this.ListingData();
   this.setParentDropDown();
   this.setNatureDropDown();
   this.setGroupNameDropDown();

  }
 

  ListingData()
  {
    this.restHtpp.getData("GroupName=&ParentGroupID=&NatureID=&PrintSequence=&InstituteId="+this.globals.InstituteId,"AccountGroupMaster/GetGroup").then(
   // this.restHtpp.getData("&InstituteId="+this.globals.InstituteId+"&UsereId="+this.globals.UserId,"AccountGroupMaster/GetGroup").then(
      (res)=>{    
        //alert(JSON.stringify(res));         
                this.groupListing=res.ResponseBody;
                //alert(this.groupListing);
                this.dataSource = new MatTableDataSource(this.groupListing);
               // alert(JSON.stringify(res));    
                this.dataSource.paginator = this.paginator;
                this.dataSource.sort = this.sort;
             }
         ).catch((err)=>{
             alert('Error Occure '+err);
         });
  }
  
  closeAlert()
  {
     
     this.successAlert=false;
  } 
 
  closeDangerAlert()
  {
    this.dangerAlert=false;
  }

  ListingData1()
  {
    // alert(this.groupForm.controls['ParentGroupId'].value);
    // alert(this.groupForm.controls['NatureId'].value);
   var str="GroupName="+this.groupForm.controls['GroupName'].value+"&ParentGroupId="+this.groupForm.controls['ParentGroupId'].value+"&NatureID="+this.groupForm.controls['NatureId'].value+"&PrintSequence="+this.groupForm.controls['ReportSequenceNo'].value+"&InstituteId="+this.globals.InstituteId;
   //alert(str);
   console.log(str);
    this.restHtpp.getData(str,"AccountGroupMaster/GetGroup").then(
      (res)=>{  
        /*  ------------Old Data----------------------------
             // alert(JSON.stringify(res));         
                this.groupListing=res.ResponseBody;
                //alert(this.groupListing);
                this.dataSource = new MatTableDataSource(this.groupListing);
               // alert(JSON.stringify(res));    
                this.dataSource.paginator = this.paginator;
                this.dataSource.sort = this.sort;*/

                
               // alert(JSON.stringify(res));     
                let resModel:ResponseModel=res;
        
                       if( resModel.ResponseStatus==="Success")
                       {
                        this.groupListing=resModel.ResponseBody;
                        this.dataSource = new MatTableDataSource(this.groupListing);   
                        this.dataSource.paginator = this.paginator;
                        this.dataSource.sort = this.sort;
                  
                       }
                       else  if( resModel.ResponseStatus==="Error")
                       {        
                          this.dangerAlert=true;
                          this.AlertMessage=resModel.ResponseMessage;
                            
                       }                 
        
                     }
         ).catch((err)=>{
             alert('Error Occure '+err);
         });
  }

  deleteModel:GroupListingModel;
  deleteGroupList(item)
  {
  this.deleteModel=item;
   this.dangerModal.show();
  // alert(JSON.stringify(item));
  }

  deleteConfirm()
  {
       this.dangerModal.hide();
       //alert("Deleteing...");
       //this.restHtpp.getData("id="+this.deleteModel.GroupID+"&UserName="+this.globals.UserName,"AccountGroupMaster/DeleteGroup").then(
       // this.restHtpp.getData("InstituteId="+this.globals.InstituteId+"&UserName="+this.globals.UserName,"AccountGroupMaster/DeleteGroup").then(
          this.restHtpp.getData("id="+this.deleteModel.GroupID+"&InstituteId="+this.globals.InstituteId+"&UserId="+this.globals.UserId+"&UserName="+this.globals.UserName,"AccountGroupMaster/DeleteGroup").then(
          (res)=>{ 
          
          //alert(JSON.stringify(res));     
          let resModel:ResponseModel=res;

          if( resModel.ResponseStatus==="Success")
          {
            //alert("Success");
                  this.groupListing=resModel.ResponseBody;

                  this.successAlert=true;
                  this.AlertMessage=resModel.ResponseMessage;

                  this.dataSource = new MatTableDataSource(this.groupListing);
                  this.dataSource.paginator = this.paginator;
                  this.dataSource.sort = this.sort;
          }
          else  if( resModel.ResponseStatus==="Error")
          {
            //alert("Error");
             this.dangerAlert=true;
             this.AlertMessage=resModel.ResponseMessage;
               //  alert  (resModel.ResponseMessage);
               //  alert  (resModel.ErrorMessage);
          }


                //   this.groupListing=res;
                //  // alert(res);
                //   this.dataSource = new MatTableDataSource(this.groupListing);
                //   this.dataSource.paginator = this.paginator;
                //   this.dataSource.sort = this.sort;
               }
           ).catch((err)=>{
               alert('Error Occure '+err);
           });

  }

  fillGroup()
 {
      for(let i=0;i<this.nameList.length;i++)
      {
         // alert(i+"-"+JSON.stringify(this.nameList[i]));
         let temp={"value":this.nameList[i].GroupId,"label":this.nameList[i].GroupName};    
         this.groupList.push(temp);
      } 
      
     // alert("fillgroup-"+JSON.stringify(this.groupList));
 }

 fillNature() 
 {
      for(let i=0;i<this.listNature.length;i++)
      {
          //alert(i+"Nature"+JSON.stringify(this.listNature[i]));
         let temp={"value":this.listNature[i].NatureID,"label":this.listNature[i].NatureName};    
         this.natureList.push(temp);
      } 
      
     // alert("fillnature-"+JSON.stringify(this.natureList));
 }
 fillGroupName() 
 {
      for(let i=0;i<this.listGroupName.length;i++)
      {
          //alert(i+"Nature"+JSON.stringify(this.listNature[i]));
         let temp={"value":this.listGroupName[i].GroupName,"label":this.listGroupName[i].GroupName};    
         this.groupIdGroupNameList.push(temp);
      } 
      
     // alert("fillnature-"+JSON.stringify(this.natureList));
 }

 setGroupNameDropDown()
 {
     
        this.restHtpp.getData("instituteID="+this.globals.InstituteId,"FillDropDown/GetGroupWithCode")
      . then(
       (res)=>{   
             //alert("GRouplist "+   JSON.stringify(res));         
 
                this.listGroupName=res.ResponseBody;
               // alert("parentDropdown"+JSON.stringify( this.nameList));
                this.fillGroupName();
                    
              }
          ).catch((err)=>{
              alert('Error Occure '+err);
          });
 }

 setParentDropDown()
 {
     
        this.restHtpp.getData("InstituteId="+this.globals.InstituteId,"FillDropDown/FillGroup")
      . then(
       (res)=>{   
             //alert("GRouplist "+   JSON.stringify(res));         
 
                this.nameList=res.ResponseBody;
               // alert("parentDropdown"+JSON.stringify( this.nameList));
                this.fillGroup();
                    
              }
          ).catch((err)=>{
              alert('Error Occure '+err);
          });
 }
  
 
 
 setNatureDropDown()
 {
     
        this.restHtpp.getData("InstituteId="+this.globals.InstituteId,"FillDropDown/FillNature")
      . then(
       (res)=>{   
            // alert("Naturelist "+   JSON.stringify(res));         
 
                this.listNature=res.ResponseBody;
               // alert("natureDropdown"+JSON.stringify( this.listNature));
                this.fillNature();
                    
              }
          ).catch((err)=>{
              alert('Error Occure '+err);
          });
 }

 applyFilter(event: Event) {
  const filterValue = (event.target as HTMLInputElement).value;
  this.dataSource.filter = filterValue.trim().toLowerCase();

  if (this.dataSource.paginator) 
  {
    this.dataSource.paginator.firstPage();
  }
}
 editGroupList(item)
  {
    const navigationExtras: NavigationExtras = {
      state: {
        data:item

        
        
      }
    };  
   // alert(JSON.stringify(item));
    this.route.navigate(["./account/Group"],navigationExtras);   

  }

  ngOnInit(): void {
  }

}
